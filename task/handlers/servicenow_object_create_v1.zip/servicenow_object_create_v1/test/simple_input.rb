{
  'info' =>
  {
    'username'=>'',
    'password'=>'',
    'server'=>'',
    'enable_debug_logging'=>'yes'
  },
  'parameters' =>
  {
    'error_handling' => 'Error Message',
    'table'=>'incident',
    'json_body'=>'{"category": "Software", "short_description": "Test incident"}'
  }
}
