{
  'info' => {
    'api_location'             => '',
    'api_username'             => '',
    'api_password'             => '',
	  'servicenow_api_location'  => '',
    'servicenow_api_username'  => '',
    'servicenow_api_password'  => '',
    'enable_debug_logging'     => 'Yes',
  },
  'parameters' => {
    'table_name'            => "",
    'table_sys_id'          => "",
    'attachment_input_type' => "",
    'attachment_field'      => "",
    'attachment_json'       => "",
    'submission_id'         => "",
  }
}
