{
  'info' => {
    'api_username' => "",
    'api_password' => "",
    'api_server' => "http://server:port/api",
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'method' => 'GET',
    'path' => '/CTM:People?q=\'Profile Status\'="Enabled"',
    'body' => ''
  }
}