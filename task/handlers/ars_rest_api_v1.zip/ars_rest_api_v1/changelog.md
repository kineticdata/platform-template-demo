ARS REST API V1 (2021-11-09)
* Initial version.  See README for details.