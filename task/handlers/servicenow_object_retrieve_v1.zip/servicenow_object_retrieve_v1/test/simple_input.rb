{
  'info' =>
  {
    'username'=>'',
    'password'=>'',
    'server'=>'',
    'enable_debug_logging'=>'yes'
  },
  'parameters' =>
  {
    'error_handling' => 'Error Message',
    'table' => 'incident',
    'id' => 'a9e428cac61122760075710592216c58'
  }
}
