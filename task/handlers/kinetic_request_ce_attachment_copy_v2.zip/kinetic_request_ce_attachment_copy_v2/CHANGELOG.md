Kinetic Request CE Attachment Copy V2 (2022-02-10)
* PER-252 Distinguish downloading attachments from Agent or Filehub and adjust headers accordingly.
* PER-253 Update destination submission values with attachment field details

Kinetic Request CE Attachment Copy V2 (2021-12-16)
* Initial Version of v2
* Updated code to retrieve the attachment using authentication

Kinetic Request CE Attachment Copy V1.2 (2018-05-25)
* API Server Info Value changed to allow ${space} in the url for subdomain support
(ie. https://${space}.localhost:8080/kinetic)

Kinetic Request CE Attachment Copy V1.1 (2017-11-21)
* Renamed from Copy Attachment to Attachment Copy to meet handler naming conventions
* Changed info_values from kinops_server, space_username, space_password to api_server, api_username,
api_password

Kinetic Request CE Attachment Copy V1 (2017-04-27)
* Initial version.