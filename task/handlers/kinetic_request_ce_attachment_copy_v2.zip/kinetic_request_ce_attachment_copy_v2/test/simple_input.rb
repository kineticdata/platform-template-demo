{
  'info' => {
    'api_server' => 'https://<YOUR_SPACE>.kinops.io',
    'api_username' => '',
    'api_password' => '',
    'space_slug' => '',
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Raise Error',
    'space_slug' => '',
    'field_name' => '',
    'submission_id' => '',
    'to_field_name' => '',
    'to_submission_id' => '',
    'kapp_slug' => '',
    'form_slug' => '',
  }
}